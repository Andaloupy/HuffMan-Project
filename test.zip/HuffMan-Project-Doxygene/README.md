# HuffMan-Project

This branche is for the doxygen, you need to compute the file obtained from it in doxywizard to get the doxygen :3

Cordially,
Sébastien Latronche, Daiyan Costilhes, Cassandra Brun, Daniel Iliescu, Hugo Janin.
