var searchData=
[
  ['translate_22',['translate',['../_huffman_8h.html#a4647c9c452874d80d31476ea3271a85d',1,'Huffman.c']]],
  ['tree_23',['Tree',['../struct_tree.html',1,'']]],
  ['tree_5fdepth_24',['tree_depth',['../avl_8h.html#a4aa9f0c69471517b4aa4eab475fc221f',1,'avl.c']]]
];
