var searchData=
[
  ['translate_48',['translate',['../_huffman_8h.html#a4647c9c452874d80d31476ea3271a85d',1,'Huffman.c']]],
  ['tree_5fdepth_49',['tree_depth',['../avl_8h.html#a4aa9f0c69471517b4aa4eab475fc221f',1,'avl.c']]]
];
