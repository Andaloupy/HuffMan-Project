var indexSectionsWithContent =
{
  0: "abcdhloprst",
  1: "lt",
  2: "ahs",
  3: "bcdloprst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions"
};

